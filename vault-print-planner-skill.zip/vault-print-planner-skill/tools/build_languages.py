"""Build English planner assets from the Chinese source and translation table."""
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[1]
APP=ROOT/'skills/vault-print-planner/assets/app'
d=dict(line.split('\t',1) for line in (ROOT/'tools/translations.tsv').read_text().splitlines() if '\t' in line)
pat=re.compile('|'.join(map(re.escape,sorted(d,key=len,reverse=True))))
for name in ['planner.html','planner-preview.js','planner-overview.js']:
    s=(APP/name).read_text()
    s=pat.sub(lambda m:' '+d[m[0]]+' ',s)
    s=s.translate(str.maketrans({'（':'(', '）':')','，':',','。':'.','：':':','；':';','「':'“','」':'”','、':',','＋':'+'}))
    s=s.replace('lang="zh-CN"','lang="en"').replace("toLocaleString('zh-CN')","toLocaleString('en-US')")
    s=s.replace('/planner-preview.js','/planner-preview-en.js').replace('/planner-overview.js','/planner-overview-en.js')
    s=s.replace('No.  ${i+1}  layer(s)','Layer ${i+1}').replace('No.  ${i+1}  plate(s)','Plate ${i+1}')
    s=s.replace('No.  ${c.number}  column - bottom to top','Column ${c.number} - bottom to top').replace("' No. '+n+' column(s) '","'Column '+n")
    s=s.replace('A quantity of ×1”','A quantity of ×1')
    assert not re.search(r'[\u4e00-\u9fff]',s.replace('语言','').replace('中文','')),name
    (APP/(Path(name).stem+'-en'+Path(name).suffix)).write_text(s)
(APP/'translations.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
