import * as THREE from 'three';
import {OrbitControls} from './vendor/three/OrbitControls.js';
import {STLLoader} from './vendor/three/STLLoader.js';

const el=id=>document.getElementById(id);
const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const colors={body:0xa7bca4,inside:0xe6d7b7,accent:0xc28b50,dark:0x344e42,grid:0xcba66a};
let selection,focus='all',opened=false,mode='assembly',renderer,scene,camera,controls,model;
let parts=[],requestId=0,meshId=0,timer,aborter,currentFile='',visualKey='';
const materialCache=new Map();
function mat(c){if(!materialCache.has(c))materialCache.set(c,new THREE.MeshStandardMaterial({color:c,roughness:.75,metalness:0}));return materialCache.get(c)}
function box(parent,w,h,d,x,y,z,c=colors.body){const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat(c));m.position.set(x,y,z);parent.add(m);return m}
function tub(parent,w,h,d,x,y,z,c){const t=3;box(parent,w,t,d,x,y+t/2,z,c);box(parent,t,h,d,x-w/2+t/2,y+h/2,z,c);box(parent,t,h,d,x+w/2-t/2,y+h/2,z,c);box(parent,w,h,t,x,y+h/2,z-d/2+t/2,c);box(parent,w,h,t,x,y+h/2,z+d/2-t/2,c)}
function handle(parent,w,y,z,c=colors.dark){const h=20,t=4;box(parent,t,h,7,-w/2,y+h/2,z,c);box(parent,t,h,7,w/2,y+h/2,z,c);box(parent,w+t,t,7,0,y+h,z,c)}
function grid(parent,w,d,y,z){box(parent,w,2,d,0,y,z,colors.inside);const nx=Math.max(1,Math.floor(w/42)),nz=Math.max(1,Math.floor(d/42));const cw=w/nx,cd=d/nz;
 for(let i=0;i<=nx;i++)box(parent,1.8,3,d,-w/2+i*cw,y+2,z,colors.grid);
 for(let i=0;i<=nz;i++)box(parent,w,3,1.8,0,y+2,z-d/2+i*cd,colors.grid);
}
function lock(parent,y,z,hidden){const g=new THREE.CylinderGeometry(hidden?9:11,hidden?9:11,hidden?2:9,32);const m=new THREE.Mesh(g,mat(colors.dark));m.rotation.x=Math.PI/2;m.position.set(0,y,z);parent.add(m);box(parent,hidden?13:4,hidden?2:16,2,0,y,z+(hidden?2:6),colors.accent)}
function clearModel(){meshId++;if(model){scene.remove(model);model.traverse(o=>{if(o.geometry)o.geometry.dispose()})}model=new THREE.Group();scene.add(model)}
function fit(){const bounds=new THREE.Box3().setFromObject(model);if(bounds.isEmpty())return;const size=bounds.getSize(new THREE.Vector3()),center=bounds.getCenter(new THREE.Vector3());const r=Math.max(size.x,size.y,size.z,60)*Math.max(1,1/camera.aspect)*1.25;controls.target.copy(center);camera.position.copy(center).add(new THREE.Vector3(r*1.15,r*(mode==='assembly'&&opened?1.7:.9),r*1.5));camera.near=.1;camera.far=r*30;camera.updateProjectionMatrix();controls.update()}
function init(){try{scene=new THREE.Scene();scene.background=new THREE.Color(0xeaf0e9);camera=new THREE.PerspectiveCamera(38,1,.1,20000);renderer=new THREE.WebGLRenderer({antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.outputColorSpace=THREE.SRGBColorSpace;el('scene').append(renderer.domElement);controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=true;controls.minDistance=20;scene.add(new THREE.HemisphereLight(0xffffff,0x708372,2.4));const light=new THREE.DirectionalLight(0xffffff,3);light.position.set(250,450,300);scene.add(light);const fill=new THREE.DirectionalLight(0xffe7c6,1.2);fill.position.set(-250,100,-200);scene.add(fill);
 const resize=()=>{const w=el('scene').clientWidth,h=el('scene').clientHeight;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix()};new ResizeObserver(resize).observe(el('scene'));resize();
 renderer.setAnimationLoop(()=>{controls.update();renderer.render(scene,camera)});return true;
 }catch(e){el('scene-label').textContent=' 3D rendering is unavailable in this browser ';el('visual-error').textContent=' The 3D preview could not load. Use the part images and manual below instead. '+e.message;return false}}
const available=init();
function assemble(reset=true){if(!available)return;clearModel();const st=selection.stack;const W={S:164.8,M:254,L:329.6,XL:418.8}[st.layers[0].layout],D=156.1+(st.depth-3)*42;let y=0;
 const subset=st.layers.map((l,i)=>({l,i})).filter(({i})=>focus==='all'||i===+focus);
 if(st.mods.base&&focus==='all'){if(st.mods.feet){[-1,1].forEach(x=>[-1,1].forEach(z=>box(model,26,18,24,x*(W/2-25),9,z*(D/2-25),colors.dark)));y=18}box(model,W,14,D,0,y+7,0,colors.dark);y+=16}
 subset.forEach(({l,i})=>{const H={1:51.5,2:99.5,4:195.5}[l.height],group=new THREE.Group();group.position.y=y;model.add(group);
 if(l.type==='Drawers'){
  box(group,4,H,D,-W/2+2,H/2,0);box(group,4,H,D,W/2-2,H/2,0);box(group,W,4,D,0,2,0);box(group,W,H,4,0,H/2,-D/2+2);
  let top=H-3;const fs=l.facades[0];fs.forEach(h=>{const dh=(H-6)*h/l.height,drawer=new THREE.Group();drawer.position.set(0,top-dh,opened?D*.72:0);group.add(drawer);const dw=W-12,dd=D-10;
   tub(drawer,dw,dh-3,dd,0,0,0,colors.inside);box(drawer,W-6,dh-3,5,0,(dh-3)/2,D/2-2,colors.body);lock(drawer,Math.min(dh/2,24),D/2+2,l.key==='hidden');box(drawer,24,7,1,-W*.25,dh/2,D/2+1,0xf4f3e8);
   if(l.interior!=='none'){grid(drawer,dw-8,dd-8,5,0);if(l.interior==='baseplate1h')handle(drawer,Math.min(45,dw/2),7,0);if(l.interior==='baseplate2h'){handle(drawer,Math.min(45,dw/2),7,-dd*.28);handle(drawer,Math.min(45,dw/2),7,dd*.28)}}
   top-=dh;
  });
 }else{
  tub(group,W,H,D,0,0,0,colors.body);
  if(l.baseplate)grid(group,W-12,D-12,5,0);
  if(l.dividers||l.variant==='Dividers'||l.variant==='Sealed'){
   if(l.variant==='Dividers'){for(let k=1;k<=2;k++){box(group,W-8,H*.6,2,0,H*.3+4,-D/2+D*k/3,colors.inside);box(group,2,H*.6,D-8,-W/2+W*k/3,H*.3+4,0,colors.inside)}}
   else for(let k=1;k<=(l.variant==='Sealed'?3:2);k++)box(group,2,H*.65,D-8,-W/2+W*k/(l.variant==='Sealed'?4:3),H*.325+4,0,colors.inside);
  }
  const lid=new THREE.Group();lid.position.set(0,H,-D/2);lid.rotation.x=opened?-Math.PI*.55:0;group.add(lid);box(lid,W,5,D,0,2.5,D/2,colors.body);
  [-1,1].forEach(x=>{box(group,13,15,7,x*W*.32,H*.72,D/2+3,colors.dark);box(group,17,6,6,x*W*.32,H-3,-D/2,colors.accent)});
 }
 if(l.manualSupports&&l.type==='Drawers')box(group,4,H*.9,5,W/2+14,H*.45,0,colors.accent);
 if(l.printed!==undefined)group.traverse(o=>{if(o.isMesh)o.material=mat(l.printed?0x699c73:0xd4d9d0)});
 y+=H+(opened&&focus==='all'?D*.65+35:5);
 });
 if(st.roof.type!=='none'&&(focus==='all'||+focus===st.layers.length-1)){
  const roof=new THREE.Group();roof.position.y=y;model.add(roof);
  if(st.roof.type==='grid')grid(roof,W,D,2,0);
  else if(st.roof.type==='bowl')tub(roof,W,13,D,0,0,0,colors.body);
  else{box(roof,W,6,D,0,3,0,colors.body);if(st.roof.type==='undertable')[-1,1].forEach(x=>box(roof,14,5,D,x*(W/2+6),7,0,colors.dark))}
  if(st.roof.topHandle)handle(roof,Math.min(105,W*.6),6,0);
 }
 if(reset)fit();el('scene-label').textContent=(focus==='all'?' Complete assembly ':' No.  '+(+focus+1)+'  layer(s) ')+' · '+(opened?(focus==='all'?' Open / exploded view ':' Open view '):' Closed view ')+' ·  Simplified geometry ';
}
function story(){const st=selection.stack;const selected=focus==='all'?st.layers.map((l,i)=>({l,i})):[{l:st.layers[+focus],i:+focus}];
 el('selection-story').innerHTML=selected.map(({l,i})=>{const type=l.type==='Drawers';return `<b> Layer ${i+1}  · ${esc(l.layout+st.depth)} · ${l.height}F ${type?' Drawer ':' Hinged storage box '}</b><br>`+(type?` One  ${l.height}F  body containing  ${l.facades[0].length}  drawers (top to bottom: ${l.facades[0].join('F + ')}F).${{none:' Empty drawer: the drawer box only, without a grid baseplate or dividers. ',baseplate:' Add a  Gridfinity  grid baseplate to locate compatible bins. Bins are not included. ',baseplate1h:' The grid baseplate has one handle for lifting the internal baseplate, not the entire box. ',baseplate2h:' The grid baseplate has two handles for lifting the internal baseplate, not external box handles. '}[l.interior]}${l.key==='hidden'?' The hidden lock uses a different two-part design. See the actual lock  STL.':' The standard facade lock holds the drawer closed; it is not a separate metal keyed lock. '}`:` The lid opens upward, with side hinges and front latches. ${l.variant==='Sealed'?' Enclosed-divider version selected; this does not imply certified waterproofing or sealing. ':l.variant==='Dividers'?' Cross dividers create multiple storage compartments. ':l.dividers?' Includes two dividers. ':' The default interior is an undivided box. '}${l.baseplate?' Add a  Gridfinity  grid baseplate inside the bottom. ':''}`)}).join('<br><br>');
 const tags=['1F / 2F / 4F =  height class ',' Light green: body ',' Beige: interior ',' Brown: grid / accessories ',' Dark green: locks / handles '];
 el('selection-tags').innerHTML=tags.map(t=>'<span>'+esc(t)+'</span>').join('');
 document.querySelectorAll('#layers > .layer').forEach((e,i)=>{e.classList.toggle('active-layer',focus!=='all'&&i===+focus);let h=e.querySelector('.option-help');if(!h){h=document.createElement('div');h.className='option-help';e.append(h)}h.textContent=st.layers[i].type==='Drawers'?'1F  is shallow; 2F / 4F  are taller. Drawer arrangement sets the number of drawers per shell. Use Open to see inside to inspect baseplates and handles. Handle options depend on the files available for this size. ':' Hinged boxes open from above. Dividers separate compartments; the Gridfinity  baseplate locates compatible bins. '});
}
function toolbar(){el('view-assembly').setAttribute('aria-pressed',String(mode==='assembly'&&!opened));el('view-open').setAttribute('aria-pressed',String(mode==='assembly'&&opened));}
const kindNames={module:' Body / shell ',box:' Drawer box ',facade:' Facade ',baseplate:' Internal grid baseplate ',key:' Facade lock ',roof:' Lid / top cover ',hinges:' Hinges ',dividers:' Dividers ',base:' Base ',feet:' Feet ','lock mechanism':' Latch assembly ','manual supports':' Print brace '};
function partLabel(p){if(p.name==='Springs')return ' Facade springs ';if(p.name==='Label'||p.name==='Label for Sustainers')return ' Label insert ';if(p.name==='Facade Cap')return ' Facade cap ';if(/Hidden Key Part 2/i.test(p.name))return ' Hidden lock - second part ';if(/Hidden Key/i.test(p.name))return ' Hidden lock - body ';if(/^Key Cap/.test(p.name))return ' Standard lock - cap ';if(/^Key \(/.test(p.name))return ' Standard lock - body ';if(/Baseplate.*1 Handle/i.test(p.name))return ' Grid baseplate - one handle ';if(/Baseplate.*2 Handles/i.test(p.name))return ' Grid baseplate - two handles ';if(/Handle/i.test(p.name))return ' Handle ';return kindNames[p.kind]||({'runners':' Runners / stoppers ','spring':' Springs '}[p.kind])||' Assembly accessories '}
function cards(){const wanted=parts.filter(p=>focus==='all'||p.group.startsWith(`L${+focus+1} ·`)||(+focus===selection.stack.layers.length-1&&p.group.startsWith('Roof')));const priority={module:0,box:1,baseplate:2,key:3,facade:4,roof:5,dividers:6,hinges:7};const rank=p=>/Key/i.test(p.name)?3:(priority[p.kind]??10);wanted.sort((a,b)=>rank(a)-rank(b));el('visual-parts').innerHTML=wanted.map(p=>`<button class="visual-card" data-file="${esc(p.file||'')}" aria-pressed="${mode==='part'&&currentFile===p.file}" ${p.file?'':'disabled'}>${p.file?`<img loading="lazy" src="/thumb/${encodeURIComponent(p.file)}" alt="${esc(partLabel(p))}">`:''}<b>${esc(partLabel(p))}</b><small>${esc(p.name)}</small></button>`).join('');el('visual-parts').querySelectorAll('button').forEach(b=>b.onclick=()=>showPart(parts.find(p=>p.file===b.dataset.file)));}
async function showPart(p,scroll=true){if(!available||!p)return;mode='part';currentFile=p.file;if(scroll)el('scene').scrollIntoView({behavior:'smooth',block:'center'});toolbar();cards();clearModel();const token=meshId;el('scene-label').textContent=' Loading actual  STL:'+partLabel(p);
 try{const geo=await new STLLoader().loadAsync('/stl/'+encodeURIComponent(p.file));if(token!==meshId){geo.dispose();return}geo.computeBoundingBox();const size=geo.boundingBox.getSize(new THREE.Vector3());geo.center();geo.computeVertexNormals();const m=new THREE.Mesh(geo,mat(colors.body));m.rotation.x=-Math.PI/2;model.add(m);fit();el('scene-label').textContent=' Actual  STL · '+partLabel(p)+' · '+[size.x,size.y,size.z].map(v=>v.toFixed(1)).join(' × ')+' mm';}
 catch(e){if(token===meshId)el('scene-label').textContent='STL  failed to load. Click the part again. '}
}
async function fetchParts(){const id=++requestId;aborter?.abort();aborter=new AbortController();el('visual-status').textContent=' Matching parts to your configuration... ';parts=[];cards();try{const r=await fetch('/api/planner/visual',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(selection),signal:aborter.signal});const data=await r.json();if(!r.ok)throw Error(data.error||' Part lookup failed ');if(id!==requestId)return;parts=data.parts;cards();if(selection.stack.mode==='accessories'&&parts.length)showPart(parts[0],false);el('visual-status').textContent=` Matched  ${parts.length}  parts. Initial thumbnail generation may take a few seconds. `;el('visual-error').textContent=data.warnings.length?data.warnings.join(';'):'';}catch(e){if(id===requestId&&e.name!=='AbortError')el('visual-status').textContent=' Could not load part images: '+e.message;}}
function update(data){selection=data;const acc=data.stack.mode==='accessories';['focus-layer','view-assembly','view-open'].forEach(id=>el(id).hidden=acc);if(acc){focus='all';mode='part';if(available)clearModel();el('scene-label').textContent=' Accessories only - select items on the left to view their actual  STL';el('selection-story').textContent=' Only selected accessories are printed. Click the cards to inspect each part in a set. Drawer boxes and shells are excluded. ';el('selection-tags').innerHTML='';const key=JSON.stringify(data.stack);if(key!==visualKey){visualKey=key;requestId++;aborter?.abort();parts=[];cards();clearTimeout(timer);timer=setTimeout(fetchParts,180)}else if(parts.length)showPart(parts[0],false);return;}if(focus!=='all'&&+focus>=data.stack.layers.length)focus='all';if(window.vaultFocus==='all'||Number.isInteger(window.vaultFocus)){focus=String(window.vaultFocus);window.vaultFocus=null}if(['interior','baseplate','dividers','variant'].includes(window.vaultChangedKey))opened=true;window.vaultChangedKey=null;el('focus-layer').innerHTML='<option value="all"> View complete assembly </option>'+data.stack.layers.map((l,i)=>`<option value="${i}"> Layer ${i+1}  · ${l.height}F ${l.type==='Drawers'?' Drawer ':' Hinged box '}</option>`).join('');el('focus-layer').value=focus;mode='assembly';currentFile='';toolbar();story();assemble();const key=JSON.stringify(data.stack);if(key!==visualKey){visualKey=key;requestId++;aborter?.abort();parts=[];cards();el('visual-status').textContent=' Updating... ';clearTimeout(timer);timer=setTimeout(fetchParts,180)}else cards();}
el('focus-layer').onchange=()=>{focus=el('focus-layer').value;mode='assembly';toolbar();story();assemble();cards()};
el('view-assembly').onclick=()=>{opened=false;mode='assembly';toolbar();assemble();cards()};
el('view-open').onclick=()=>{opened=true;mode='assembly';toolbar();assemble();cards()};
el('view-reset').onclick=()=>{if(available)fit()};
window.addEventListener('vault-selection',e=>update(e.detail));
update(window.vaultSelection());

window.addEventListener('vault-overall',e=>{
 if(!available)return;
 const data=e.detail;requestId++;aborter?.abort();clearTimeout(timer);visualKey='';
 clearModel();const combined=new THREE.Group();let x=0;
 for(const col of data.columns){selection={stack:col.stack};focus='all';opened=false;mode='assembly';assemble(false);const component=model;scene.remove(component);model=null;
 const bounds=new THREE.Box3().setFromObject(component),width=bounds.max.x-bounds.min.x;component.position.x=x-bounds.min.x;combined.add(component);x+=width+55;
 }
 model=combined;scene.add(model);fit();['focus-layer','view-assembly','view-open'].forEach(id=>el(id).hidden=true);
 el('scene-label').textContent=(data.demo?' Demo - records unchanged  · ':' Overall plan  · ')+ '   Green: printed / gray: pending - simplified stack view ';
 el('selection-story').textContent=` Left to right: ${data.columns.map(c=>' No.  '+c.number+'  column(s) ').join(',')}.${data.demo?' Demo progress ':' Plan completed '} ${data.completed} / ${data.target}  sets. Covers and bases keep their original colors; body colors show completion. `;
 el('selection-tags').innerHTML='<span> Green: printed </span><span> Gray: pending </span><button id="back-to-selection"> Return to current configuration </button>';
 el('back-to-selection').onclick=()=>update(window.vaultSelection());
 el('visual-parts').innerHTML='';el('visual-status').textContent=' This overview does not create print tasks. Use the original tasks for remaining sets. ';el('visual-error').textContent=data.warnings.join(';');el('scene').scrollIntoView({behavior:'smooth',block:'center'});
});
