/* Translate only system-owned response fields. User names, notes and file paths stay intact. */
(() => {
  const english = document.documentElement.lang === 'en';
  if (!english && !location.search.includes('lang=zh-CN') && localStorage.getItem('vault-language') === 'en') {
    location.replace('/planner-en.html' + location.hash);
  }
  if (!english) return;
  const originalFetch = window.fetch.bind(window);
  const dictionary = originalFetch('/translations.json').then(r => r.json());
  window.fetch = async (...args) => {
    const response = await originalFetch(...args);
    if (!String(args[0]).includes('/api/planner/') || !response.headers.get('content-type')?.includes('json')) return response;
    const d = await dictionary;
    const expression = new RegExp(Object.keys(d).sort((a,b)=>b.length-a.length).map(s=>s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|'),'g');
    const translate = s => s.replace(expression,m=>' '+d[m]+' ').replace(/ {2,}/g,' ').trim();
    const visit = (value, key='', parent='') => {
      if (typeof value === 'string') return ['error','label','group','warning','warnings','blockers'].includes(key) || (key==='note' && !['progress','history'].includes(parent)) ? translate(value) : value;
      if (Array.isArray(value)) return value.map(v=>visit(v,key,parent));
      if (value && typeof value==='object') return Object.fromEntries(Object.entries(value).map(([k,v])=>[k,visit(v,k,key)]));
      return value;
    };
    return new Response(JSON.stringify(visit(await response.json())),{status:response.status,statusText:response.statusText,headers:response.headers});
  };
})();
