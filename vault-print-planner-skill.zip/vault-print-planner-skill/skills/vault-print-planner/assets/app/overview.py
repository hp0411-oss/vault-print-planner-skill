"""Manual inventory and a four-column assembly plan, independent of slicing jobs."""
import json
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
from copy import deepcopy

PATH=Path(__file__).parent/'print-progress.json'

def read():
    return json.loads(PATH.read_text()) if PATH.exists() else {}

def update(jid,body):
    values={}
    for key,limit in [('target',20),('printed',100),('column',4),('order',100)]:
        v=body.get(key,0)
        if type(v)!=int or not 0<=v<=limit:raise ValueError(f'{key} 数值需为 0–{limit} 的整数')
        values[key]=v
    note=body.get('note','')
    if not isinstance(note,str) or len(note)>300:raise ValueError('备注最多 300 字')
    values.update(note=note,updated=datetime.now(ZoneInfo('America/Los_Angeles')).isoformat())
    data=read();previous=data.get(jid,{})
    values['history']=(previous.get('history',[])+[dict(at=values['updated'],printed=values['printed'],target=values['target'])])[-100:]
    data[jid]=values
    tmp=PATH.with_suffix('.tmp');tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2));tmp.replace(PATH)

def build(jobs):
    records=read();items=[];columns=[];warnings=[]
    for j in jobs:
        r=records.get(j['id'],dict(target=0,printed=0,column=0,order=0,note=''))
        if j.get('deleted_at') and not (r['printed'] or r['target']):continue
        items.append(dict(job=j,progress=r))
    for n in range(1,5):
        chosen=sorted([i for i in items if i['progress']['column']==n and i['progress']['target'] and i['job']['stack'].get('mode')!='accessories'],key=lambda i:(i['progress']['order'],i['job']['created'],i['job']['id']))
        if not chosen:continue
        units=[]
        for i in chosen:
            for q in range(i['progress']['target']):units.append((i['job'],q<i['progress']['printed']))
        sizes={(j['stack']['layers'][0]['layout'],j['stack']['depth']) for j,done in units}
        if len(sizes)>1:
            warnings.append(f'第 {n} 列宽度或深度不同，不能按当前规则直接堆叠；请分到不同列。');continue
        if sum(len(j['stack']['layers']) for j,done in units)>48:
            warnings.append(f'第 {n} 列超过 48 层，请拆成多列预览。');continue
        layers=[];labels=[]
        for u,(j,done) in enumerate(units):
            st=j['stack'];layers.extend([dict(l,printed=done,manualSupports=False) for l in st['layers']]);labels.append(dict(name=st['name'],printed=done))
            if u<len(units)-1 and st['layers'][-1]['type']=='Sustainers':warnings.append(f'第 {n} 列「{st["name"]}」上方有其他模块，翻盖前需移开上方模块。')
            if u<len(units)-1 and st.get('roof',{}).get('type','none')!='none':warnings.append(f'第 {n} 列中间顶盖不计入堆叠示意，原有顶盖可能需拆下另用。')
            if u>0 and st.get('mods',{}).get('base'):warnings.append(f'第 {n} 列只保留最底部底座，上方组的底座未计入示意。')
        first=units[0][0]['stack'];last=units[-1][0]['stack']
        columns.append(dict(number=n,labels=labels,stack=dict(name=f'第 {n} 列',layers=layers,depth=first['depth'],roof=deepcopy(last.get('roof',{'type':'none'})),mods=deepcopy(first.get('mods',{})))))
    target=sum(i['progress']['target'] for i in items)
    completed=sum(min(i['progress']['printed'],i['progress']['target']) for i in items)
    return dict(items=items,columns=columns,warnings=list(dict.fromkeys(warnings)),target=target,completed=completed,printed=sum(i['progress']['printed'] for i in items))
