"""Discover supported single-nozzle Bambu machines from locally installed Studio profiles."""
import math
import presets

DEFAULT = 'Bambu Lab P1S'
NOZZLES = ('0.4', '0.6')

def geometry(machine):
    def points(value):
        result = [tuple(float(v) for v in str(p).strip().split('x')) for p in value]
        if any(len(p) != 2 or not all(math.isfinite(v) for v in p) for p in result):
            raise ValueError('Invalid printer area')
        return result
    area = points(machine.get('printable_area') or [])
    if len(area) != 4:
        raise ValueError('Only rectangular printer beds are supported')
    xs, ys = sorted(set(p[0] for p in area)), sorted(set(p[1] for p in area))
    if len(xs) != 2 or len(ys) != 2 or xs[0] != 0 or ys[0] != 0 or set(area) != {(x,y) for x in xs for y in ys}:
        raise ValueError('Only rectangular zero-origin printer beds are supported')
    height = float(machine.get('printable_height', 0))
    if not math.isfinite(height) or height <= 0:
        raise ValueError('Invalid printer height')
    # Reserve a front strip and edge room; then conservatively avoid the entire
    # bounding rectangle of the profile's exclusion points, with 5 mm clearance.
    bounds = [20., 20., xs[1]-6., ys[1]-6.]
    excluded = points(machine.get('bed_exclude_area') or [])
    if excluded and max(x for x,y in excluded)>min(x for x,y in excluded) and max(y for x,y in excluded)>min(y for x,y in excluded):
        ex0,ex1=min(x for x,y in excluded)-5,max(x for x,y in excluded)+5
        ey0,ey1=min(y for x,y in excluded)-5,max(y for x,y in excluded)+5
        x0,y0,x1,y1=bounds
        if ex0<x1 and ex1>x0 and ey0<y1 and ey1>y0:
            candidates=[[x0,y0,min(x1,ex0),y1],[max(x0,ex1),y0,x1,y1],
                        [x0,y0,x1,min(y1,ey0)],[x0,max(y0,ey1),x1,y1]]
            candidates=[b for b in candidates if b[2]>b[0] and b[3]>b[1]]
            if not candidates: raise ValueError('No usable bed area after exclusions')
            bounds=max(candidates,key=lambda b:(b[2]-b[0])*(b[3]-b[1]))
    if bounds[2]<=bounds[0] or bounds[3]<=bounds[1]: raise ValueError('No usable bed area')
    return dict(bed=[xs[1],ys[1]],height=height,offset=bounds[:2],planningBed=[bounds[2]-bounds[0],bounds[3]-bounds[1]])

def resolve(printer=DEFAULT,nozzle='0.4'):
    if nozzle not in NOZZLES: raise ValueError('Supported nozzles: 0.4 / 0.6 mm')
    machines=presets.load_all('bambu','machine')
    name=f'{printer} {nozzle} nozzle'
    p=machines.get(name)
    if not p or str(p.get('instantiation','true')).lower()=='false':
        raise ValueError(f'Missing Bambu Studio machine profile: {name}')
    m=presets.flatten(name,machines)
    if m.get('printer_model')!=printer or not printer.startswith('Bambu Lab '):
        raise ValueError('Unsupported machine profile')
    diameters=m.get('nozzle_diameter') or []
    if len(diameters)!=1:
        raise ValueError('Dual-nozzle machines are not supported by this planner yet')
    if float(diameters[0])!=float(nozzle): raise ValueError('Nozzle profile mismatch')
    return name,m,geometry(m)

def compatible_rows(machine,kind):
    return [r for r in presets.catalog('bambu',machine,kind) if machine in r['printers']]

def catalog():
    machines=presets.load_all('bambu','machine')
    models=sorted({presets.flatten(n,machines).get('printer_model','') for n,p in machines.items()
        if str(p.get('instantiation','true')).lower()!='false' and n.startswith('Bambu Lab ')})
    rows=[]
    for model in models:
        if not model: continue
        row=dict(name=model,nozzles=[],variants={},reason='')
        for nozzle in NOZZLES:
            try:
                name,m,g=resolve(model,nozzle)
                if not any('Standard' in p['name'] for p in compatible_rows(name,'process')):
                    raise ValueError('Missing compatible Standard process profile')
                row['nozzles'].append(nozzle);row['variants'][nozzle]=g;row.update(g)
            except (ValueError,TypeError) as exc:
                row['reason']=str(exc)
        if row['nozzles']: row['reason']=''
        rows.append(row)
    return dict(default=DEFAULT,printers=rows)
