"""Explicit accessory bundles. Never include an enclosing drawer or module."""
from copy import deepcopy
import catalog


def options(stack,index,site):
    l=stack['layers'][0];f=l['layout'];d=int(stack['depth']);h=int(l['height'])
    out=[]
    def offer(key,label,note,fill,keep=None,hardware=False):
        b=catalog.Bom(index,site,lambda rel:True);fill(b)
        result=b.result(stack)
        if keep:result['parts']=[p for p in result['parts'] if keep(p)]
        if not result['parts'] or any(not p['file'] for p in result['parts']) or result['warnings']:return
        if not hardware:result['hardware']=[]
        out.append(dict(id=key,label=label,note=note,**result))
    def drawer(b,interior='none',key='key'):
        b.drawer_layer(0,dict(l,type='Drawers',interior=interior,key=key,facades=[[h]],labels=True,manualSupports=False),d,{})
    def sustainer(b,variant='Flat',baseplate=False,dividers=False):
        b.sustainer_layer(0,dict(l,type='Sustainers',variant=variant,baseplate=baseplate,dividers=dividers,divW=2,divD=2),d,{})
    if l['type']=='Drawers':
        for ident,label in [('baseplate','普通网格底板'),('baseplate1h','网格底板 · 一个提手'),('baseplate2h','网格底板 · 两个提手')]:
            if ident=='baseplate1h' and f!='S':continue
            if ident=='baseplate2h' and not(f in ('S','M') or(f=='L' and d==4)):continue
            offer(ident,label,'一套供一个抽屉使用。提手与底板同属这一款文件。',lambda b,v=ident:drawer(b,v),lambda p:p['kind']=='baseplate')
        for ident,label in [('key','标准面板锁'),('hidden','隐藏面板锁')]:
            offer(ident,label,'一套含该锁的主体及配套第二件／盖，复用现有面板与弹簧。',lambda b,v=ident:drawer(b,key=v),lambda p:p['name'].startswith(('Key (','Key Cap','Hidden Key')))
        offer('runners','抽屉导轨与限位件','供一个抽屉使用，文件内已含成对导轨。',drawer,lambda p:p['kind']=='runners')
        for ident,name,label in [('springs','Springs','面板弹簧（成对）'),('label','Label','抽屉标签片')]:
            offer(ident,label,'按完整 STL 打印一套。',lambda b,n=name:b.add('配件',n,'drawers universal'))
        for ident,title in [('grid','网格顶盖'),('table','平面顶盖'),('bowl','浅盘顶盖'),('undertable','桌下安装顶盖')]:
            offer('roof-'+ident,title,'仅顶盖，不含下方抽屉外壳。',lambda b,v=ident:b.roof(dict(stack,roof=dict(type=v,topHandle=False)),l,d))
        def top_handle(b):
            b.add('配件','Top Handle (Turn On Supports)','drawers universal');b.hw('M6 x 50 mm countersunk bolt',2,'roof handle')
        offer('top-handle','网格顶盖提手','安装到已有网格顶盖；不是内部底板提手。另备两颗螺栓。',top_handle,hardware=True)
    else:
        offer('baseplate','翻盖箱网格底板','一套供一个匹配尺寸的翻盖箱使用。',lambda b:sustainer(b,baseplate=True),lambda p:p['kind']=='baseplate')
        offer('dividers','内部隔板套装','S/M 为两片；L/XL 为交叉隔板，须与原分隔箱体的插槽匹配。',lambda b:sustainer(b,'Dividers' if f in ('L','XL') else 'Flat',dividers=True),lambda p:p['kind']=='dividers')
        offer('label','翻盖箱标签片','仅标签片。',lambda b:b.add('配件','Label for Sustainers','sustainers'))
    offer('base','匹配底座','仅底座。大尺寸仍需通过 P1S 排板检查。',lambda b:b.mods(dict(stack,mods={'base':True}),d))
    offer('feet','底座支脚','安装到已有匹配底座；一套按原 STL 打印。',lambda b:b.mods(dict(stack,mods={'feet':True}),d),hardware=True)
    return out


def build(stack,index,site,allow_empty=False):
    rows=stack.get('accessories',[])
    if not isinstance(rows,list) or len(rows)>30:raise ValueError('配件选择格式无效')
    if not rows and not allow_empty:raise ValueError('请至少选择一种配件')
    choices={o['id']:o for o in options(stack,index,site)}
    parts=[];hw={};seen=set()
    for row in rows:
        key=row.get('id');q=row.get('qty')
        if key not in choices or key in seen:raise ValueError('配件与当前尺寸不匹配，请重新选择')
        if type(q)!=int or not 1<=q<=20:raise ValueError('每种配件套数需为 1–20')
        seen.add(key);o=choices[key]
        for src in o['parts']:
            p=deepcopy(src);p.update(id=f'p{len(parts)+1}',group='配件 · '+o['label'],qty=p['qty']*q)
            parts.append(p)
        for item in o['hardware']:
            dest=hw.setdefault(item['item'],dict(item,qty=0));dest['qty']+=item['qty']*q
    return dict(parts=parts,hardware=list(hw.values()),warnings=[])
