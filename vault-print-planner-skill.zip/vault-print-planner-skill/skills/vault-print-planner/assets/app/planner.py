"""Chinese, local-only planning workflow for the owner's 261020 VAULT archive."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
from copy import deepcopy
import json, uuid, threading, subprocess, csv, re
import catalog, plates, presets, accessories, overview, printer_profiles

HERE=Path(__file__).parent
JOBS=HERE/'print-jobs'
LOCK=threading.Lock()
BUSY=set()

def save(job):
    JOBS.mkdir(exist_ok=True)
    path=JOBS/(job['id']+'.json')
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(job,ensure_ascii=False,indent=2));tmp.replace(path)

def read(jid, allow_deleted=False):
    if not re.fullmatch(r'[a-f0-9]{12}',jid or ''):raise ValueError('任务编号无效')
    path=JOBS/(jid+'.json')
    if not path.exists():raise ValueError('找不到这个任务')
    job=json.loads(path.read_text())
    if job.get('deleted_at') and not allow_deleted:raise ValueError('任务已删除，请先在“已删除任务”中恢复')
    return job

def settings(material='PLA', nozzle='0.4', printer=printer_profiles.DEFAULT):
    if material not in ('PLA','PETG'):raise ValueError('请选择 PLA 或 PETG')
    machine,m,geometry=printer_profiles.resolve(printer,nozzle)
    candidates=printer_profiles.compatible_rows(machine,'process')
    process=next((r['name'] for r in candidates if 'Standard' in r['name']),None)
    if not process:raise ValueError('Missing compatible Standard process profile')
    available=printer_profiles.compatible_rows(machine,'filament')
    matching=[f for f in available if f.get('material','').upper()==material]
    matching.sort(key=lambda f:(not f['name'].startswith('Generic '+material),f['user'],f['name']))
    if not matching:raise ValueError(f'Missing compatible {material} filament profile: {machine}')
    fil=matching[0]['name']
    s=deepcopy(plates.DEFAULT_SETTINGS)
    s.update(mode='bambu', edge=1, estimateFromPreset=False, wallMm=.8,infill=.15,density=1.24 if material=='PLA' else 1.27)
    s['geometry']=geometry
    s['printers']=[dict(id='bambu',name=printer,bed=geometry['planningBed'][:],z=geometry['height'],maxH=geometry['height'],multi=False,enabled=True,slicer='bambu',profile=printer,machine=machine,nozzle=nozzle,preset=process)]
    s['filaments']=[dict(name=material,color='#89968d',material=material,preset={'bambu':fil})]
    s['roles']={k:0 for k in catalog.ROLES}
    return s

def validate(stack):
    if not isinstance(stack,dict):raise ValueError('组合格式无效')
    if int(stack.get('depth',0)) not in range(3,8):raise ValueError('深度请选择 3–7')
    layers=stack.get('layers',[])
    if not 1<=len(layers)<=12:raise ValueError('组合需要 1–12 层')
    base=layers[0].get('layout')
    if base not in catalog.FAMILIES:raise ValueError('宽度请选择 S / M / L / XL')
    for l in layers:
        if l.get('layout')!=base:raise ValueError('中文入口同一组合需统一宽度')
        h=int(l.get('height',0))
        if h not in ((1,) if base=='XL' else (1,2,4)):raise ValueError('高度不兼容')
        if l.get('type') not in ('Drawers','Sustainers'):raise ValueError('类型无效')
        if l['type']=='Drawers':
            if l.get('facades') not in [[p] for p in catalog.PATTERNS[h]]:raise ValueError('抽屉高度分配不匹配模块')
            if l.get('interior','none') not in ('none','baseplate','baseplate1h','baseplate2h'):raise ValueError('本版网格隔板端件未核对，请使用空抽屉或 Gridfinity 底板')
            interior=l.get('interior','none')
            if interior=='baseplate1h' and base!='S':raise ValueError('当前图纸只有 S 系列提供单提手底板')
            if interior=='baseplate2h' and not (base in ('S','M') or (base=='L' and int(stack['depth'])==4)):raise ValueError('此尺寸没有双提手底板文件')
            if l.get('key','key') not in ('key','hidden'):raise ValueError('请选择标准锁或隐藏锁')
        if l.get('variant','Flat') not in ('Flat','Dividers','Sealed'):raise ValueError('箱体类型无效')
        if base in ('S','M') and l.get('variant','Flat')!='Flat':raise ValueError('S / M 箱体使用标准版本')
        for key in ('divW','divD'):
            if not 0<=int(l.get(key,2))<=12:raise ValueError('隔板数量请选择 0–12')
    roof=stack.get('roof',{}).get('type','none')
    if roof not in ('none','grid','table','bowl','undertable'):raise ValueError('顶盖选项无效')
    if layers[-1]['type']=='Sustainers' and roof!='none':raise ValueError('顶层翻盖箱已包含箱盖，不再添加抽屉顶盖')
    mods=stack.get('mods') or {}
    if any(v for k,v in mods.items() if k not in ('base','feet')):raise ValueError('中文入口暂支持底座与支脚，其余改装请单独核对')
    if mods.get('feet') and not mods.get('base'):raise ValueError('支脚需要配套底座')

def compute(body,server):
    stack=deepcopy(body.get('stack'));validate(stack)
    printer=body.get('printer',printer_profiles.DEFAULT)
    s=settings(body.get('material','PLA'),body.get('nozzle','0.4'),printer)
    selected=accessories.build(stack,server.INDEX,server.SITE) if stack.get('mode')=='accessories' else None
    bom,_=server.compute_bom(dict(stack=stack,settings=s),supplied_bom=selected)
    plan=plates.plan(bom['parts'],s,server.stats_fn)
    blockers=[]
    if any(not p['file'] for p in bom['parts']):blockers.append('存在未找到的 STL，不能生成完整打印工程。')
    if plan['unplaceable']:blockers.append('部分零件无法放进所选打印机排板范围；请减小尺寸或改选组合。')
    # Translate the conservative planning rectangle into the selected machine bed.
    for pl in plan['plates']:
        for it in pl['items']:
            it['x']+=s['geometry']['offset'][0];it['y']+=s['geometry']['offset'][1]
    s['printers'][0]['bed']=s['geometry']['bed'][:]
    return dict(printer=printer,stack=stack,settings=s,bom=bom,plan=plan,blockers=blockers,material=body.get('material','PLA'),nozzle=body.get('nozzle','0.4'))

def get(handler,path):
    if path=='/api/planner/printers':return handler.send_json(printer_profiles.catalog())
    if path=='/api/planner/overview':
        with LOCK:
            jobs=[json.loads(p.read_text()) for p in JOBS.glob('*.json')] if JOBS.exists() else []
            data=overview.build(jobs)
        return handler.send_json(data)
    if path in ('/api/planner/jobs','/api/planner/deleted'):
        jobs=[json.loads(p.read_text()) for p in sorted(JOBS.glob('*.json'),reverse=True)] if JOBS.exists() else []
        jobs=[j for j in jobs if bool(j.get('deleted_at'))==(path=='/api/planner/deleted')]
        return handler.send_json(sorted(jobs,key=lambda j:j['created'],reverse=True))
    return handler.send_json({'error':'未找到'},404)

def export_job(jid,server):
    try:
        job=read(jid);bundle=compute(job,server)
        if bundle['blockers']:raise ValueError('；'.join(bundle['blockers']))
        out=HERE/'output'/('job-'+jid)
        files=plates.export(bundle['plan'],bundle['settings'],str(out),server.ROOT,server.stats_fn,stack_name='vault-'+jid)
        if any(f.get('warning') or f.get('outside') for f in files):raise ValueError('工程检查未通过：'+str([f.get('warning') for f in files]))
        rows=bundle['bom']['parts']
        with (out/'parts.csv').open('w',encoding='utf-8-sig',newline='') as f:
            w=csv.writer(f);w.writerow(['组别','零件名称','STL整套打印次数','源文件路径','说明'])
            for p in rows:w.writerow([p['group'],p['name'],p['qty'],str(Path(server.ROOT)/p['file']),p.get('note','')])
        (out/'selection.json').write_text(json.dumps(bundle,ensure_ascii=False,indent=2))
        job.update(status='ready',files=files,output=str(out),plate_count=len(bundle['plan']['plates']),error=None)
        with LOCK:save(job)
    except Exception as e:
        with LOCK:
            job=read(jid);job.update(status='error',error=str(e));save(job)
    finally:
        with LOCK:BUSY.discard(jid)

def post(handler,path,body,server):
    if path=='/api/planner/progress':
        with LOCK:
            job=read(body.get('id'),allow_deleted=True)
            overview.update(job['id'],body)
        return handler.send_json({'ok':True})
    if path in ('/api/planner/delete','/api/planner/restore'):
        jid=body.get('id')
        with LOCK:
            job=read(jid,allow_deleted=True)
            if jid in BUSY or job['status']=='exporting':raise ValueError('工程正在生成，请完成后再删除任务')
            if path.endswith('/delete'):
                job['deleted_at']=datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()
            else:
                job.pop('deleted_at',None)
            save(job)
        return handler.send_json({'ok':True})
    if path=='/api/planner/accessories':
        stack=deepcopy(body.get('stack'));validate(stack)
        return handler.send_json(accessories.options(stack,server.INDEX,server.SITE))
    if path=='/api/planner/visual':
        stack=deepcopy(body.get('stack'));validate(stack)
        # Visual catalogue only: whole parts, no mesh measurement or plate packing.
        # Printing still uses compute(), which chooses parts against the selected machine bed.
        bom=accessories.build(stack,server.INDEX,server.SITE,allow_empty=True) if stack.get('mode')=='accessories' else catalog.Bom(server.INDEX,server.SITE,lambda rel: True).build(stack)
        return handler.send_json(bom)
    if path in ('/api/planner/preview','/api/planner/save'):
        data=compute(body,server)
        if path.endswith('preview'):return handler.send_json(data)
        job={k:data[k] for k in ('stack','material','nozzle','printer')}
        job.update(id=uuid.uuid4().hex[:12],created=datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),status='blocked' if data['blockers'] else 'planned',blockers=data['blockers'],plate_count=len(data['plan']['plates']),part_count=sum(p['qty'] for p in data['bom']['parts']))
        with LOCK:save(job)
        return handler.send_json(job)
    if path=='/api/planner/export':
        jid=body.get('id')
        with LOCK:
            job=read(jid)
            if jid in BUSY:raise ValueError('此任务正在生成工程')
            if job['status']=='blocked':raise ValueError('请先解决尺寸或缺件问题，重新保存任务')
            if job['status']=='ready':return handler.send_json(job)
            job['status']='exporting';save(job);BUSY.add(jid)
        threading.Thread(target=export_job,args=(jid,server),daemon=True).start()
        return handler.send_json(job)
    if path=='/api/planner/open':
        job=read(body.get('id'))
        if job['status']!='ready':raise ValueError('请先生成打印工程')
        f=Path(job['files'][0]['file']).resolve()
        if not f.is_relative_to((HERE/'output').resolve()) or not f.exists():raise ValueError('工程文件不存在')
        subprocess.Popen(['open','-a','BambuStudio',str(f)])
        return handler.send_json({'ok':True})
    return handler.send_json({'error':'未找到'},404)
