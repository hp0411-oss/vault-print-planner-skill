#!/usr/bin/env python3
"""Launch the bundled local planner against an explicitly supplied model archive."""
import argparse
import importlib.util
import os
from pathlib import Path
import subprocess
import sys

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--archive', required=True, type=Path)
    p.add_argument('--port', type=int, default=8766)
    p.add_argument('--check', action='store_true', help='Validate dependencies and archive without starting')
    a = p.parse_args()
    if not 1024 <= a.port <= 65535:
        p.error('port must be between 1024 and 65535')
    archive = a.archive.expanduser().resolve()
    if not (archive / '01. DRAWERS').is_dir():
        p.error('archive must contain 01. DRAWERS')
    missing = [n for n in ('numpy', 'PIL', 'pypdf') if importlib.util.find_spec(n) is None]
    if missing:
        p.error('Missing Python packages: ' + ', '.join(missing) + '; install requirements.txt in this Python environment')
    app = Path(__file__).resolve().parents[1] / 'assets' / 'app'
    if a.check:
        print('Archive and Python dependencies OK; slicer presets still require app verification.')
        return 0
    env = {**os.environ, 'VAULT_ARCHIVE': str(archive), 'VAULT_PORT': str(a.port), 'HOST': '127.0.0.1'}
    print(f'Open http://127.0.0.1:{a.port}/planner.html — keep this process running.', flush=True)
    try:
        return subprocess.call([sys.executable, '-u', str(app / 'server.py'), '--offline', '--no-precache', '--no-browser'], cwd=app, env=env)
    except KeyboardInterrupt:
        return 130

if __name__ == '__main__':
    raise SystemExit(main())
