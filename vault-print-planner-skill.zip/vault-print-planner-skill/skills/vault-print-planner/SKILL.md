---
name: vault-print-planner
description: Plan USSA VAULT modular drawers and storage boxes from the user's own model archive, select accessory-only jobs, preview assemblies, track printed units, and prepare Bambu Studio projects with plate-clearance checks. Use for VAULT configuration and printing workflows, not general CAD modeling.
---

# VAULT 打印规划

把用户的 VAULT 组合意图转换为可核对的零件清单、打印工程和完成记录。使用随附的中文本地工具；原始 STL 和说明书由用户提供。

## 启动与选型

- 使用当前会话已确认的打印机、喷嘴、材料、板材；仅询问缺失项。不要把某次使用的 A3 / PETG Basic 当成所有用户的默认值。
- 先检查用户是否已有正在运行的规划工具或未保存的 Bambu 工程，避免启动重复服务或覆盖手动修改。
- 新环境读取 [运行说明](references/workflow.md)。启动命令：`python scripts/launch.py --archive /absolute/path/to/VAULT --port 8766`。相对路径按本 skill 目录解析。脚本打印网页地址，保持进程运行。
- 当前中文界面针对 P1S、0.4/0.6 mm、PLA/PETG；其他设备先核对配置或扩展代码，不冒充已支持。
- 按说明书核对系列、深度、高度、抽屉分配、内底板、把手和锁的依赖。需要单独补件时使用配件模式，不重复添加整套外壳。
- 预览是简化的组合示意；STL 单件查看用于辨认零件，二者均不证明装配公差正确。

## 导出与开打前核对

自动导出产生可编辑 3MF 工程，不代表已经切片、上传或打印。

1. 核对 BOM 对应实际文件和整套 STL 的数量；一个 STL 可能包含一对零件，不能再按单件数重复。
2. 阅读 [排板检查](references/print-preflight.md)。检查实际打印机起始 G-code 的挤出线、机床禁区、模型和 brim/support 的足迹，不能只检查 256×256 mm 边界。
3. 自动排板不合适时，将小配件分盘。不得为塞进打印板缩放装配零件。保留原文件，修改后另存新工程。
4. 高外壳需要稳定支撑时，检查原厂对应深度的 brace 是否真正接到外壳侧壁；仅在 BOM 中勾选它或把它放旁边不算完成。当前自动关联并非对所有尺寸验证过。
5. 在 Bambu Studio 按实际材料型号核对预设、板材、喷嘴，切片每个修改过的盘，检查第一层和报错。报告哪些盘已验证、哪些仍未验证；切片成功不保证实物附着。
6. 映射到实际 AMS 槽位。只有用户明确要求开始打印时才发送；“导出”“加入 Studio”“检查设置”不表示开打。

## 记录与后续组合

任务支持软删除和恢复。已打印数量由用户确认后记录，导出或发送不等于打印完成。组合总览用于核对已有与计划数量、堆叠顺序及系列/深度兼容性。部分盘失败时记录具体盘，不把整组标成完成。

## 发布与维护

保留随附代码的 AGPL-3.0 许可和上游来源。GitHub 只发布代码、skill 和自有说明；排除用户原图、付费模型、PDF、渲染缓存、工程输出、账号信息和打印记录。排板/耗材规则改变后，重新检查代表性工程，不能沿用旧任务的 ready 状态作为验证。
