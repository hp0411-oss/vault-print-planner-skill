---
name: vault-print-planner
description: Plan USSA VAULT modular drawers and storage boxes from the user's own model archive, select accessory-only jobs, preview assemblies, track printed units, and prepare Bambu Studio projects with plate-clearance checks. Use for VAULT configuration and printing workflows, not general CAD modeling.
---

# VAULT Print Planner

Turn a VAULT configuration into a reviewable parts list, print project, and completion record. Use the bundled Chinese/English local planner with the user’s own models and manuals.

## Model ownership and manuals

- Tell users clearly that this skill provides a tool, not the VAULT models. Each user must purchase models from the designer or an authorized seller, download and extract them locally, and supply that folder with `--archive`.
- Never upload or distribute purchased model geometry through GitHub or release packages. This includes STL, STEP, 3MF, converted meshes, generated print projects, and archives containing models. Keep preview and print processing local.
- The tool’s AGPL license does not license third-party models. Respect the designer’s license and attribution.
- Manuals are permitted reference inputs: read local manuals for configuration, printing, and assembly. They are not categorically prohibited resources. Include a manual in a repository or package only when the rights holder permits redistribution; otherwise use the local copy or an official reference link. The current bundle contains no third-party manuals.

## Launch and configure

- Reuse confirmed printer, nozzle, filament, and plate details. Ask only for missing information; never assume A3 or PETG Basic for every user.
- Check for an existing server and unsaved Bambu Studio work before starting another service or replacing projects.
- Read [workflow](references/workflow.md) for setup. Run `python scripts/launch.py --archive /absolute/path/to/VAULT --port 8766` relative to this skill directory. Keep the server running.
- The planner supports P1S, 0.4/0.6 mm, and PLA/PETG. Verify or extend support before using other equipment.
- Use the language selector for Chinese or English. Preserve user names, notes, and original filenames.
- Check width, depth, height, drawer arrangement, interior, handle, and lock dependencies against the manual. Use accessory mode for replacement parts.
- Simplified assembly and individual STL previews identify parts; they do not validate fit or tolerances.

## Export and preflight

An exported 3MF is editable project data, not proof of slicing, upload, or printing.

1. Verify actual BOM files and whole-file quantities; a single STL may already contain a pair of parts.
2. Read [print preflight](references/print-preflight.md). Check actual extruding start-G-code paths, exclusion zones, transformed models, brims, and supports, not just the 256 × 256 mm boundary.
3. Separate small accessories into another plate when needed. Never scale assembly parts to fit. Preserve originals and save revised projects separately.
4. Check that the matching-depth stabilization braces contact the shell correctly. Merely selecting or placing them nearby is insufficient. Automatic association has not been validated for every size.
5. Verify exact material profile, plate, and nozzle in Studio. Slice every changed plate and inspect first layers and warnings. Report which plates were checked. Successful slicing does not guarantee adhesion.
6. Map the actual AMS slot. Send only when the user explicitly asks to start printing; exporting, opening Studio, or checking settings is not authorization to print.

## Records and later builds

Tasks support recoverable deletion. Record completed quantities only after user confirmation; exporting or sending is not completion. Use the overview for quantities, stacking order, and width/depth compatibility. Record partial or failed plates in notes instead of marking a whole build complete.

## Publication and maintenance

Retain AGPL-3.0 and upstream credit. Publish code, skill resources, original documentation, and any manuals permitted for redistribution under the policy above. Exclude paid model geometry, model renders, generated projects, credentials, and print records. Recheck representative projects after layout or material changes; an old ready status is not validation.
