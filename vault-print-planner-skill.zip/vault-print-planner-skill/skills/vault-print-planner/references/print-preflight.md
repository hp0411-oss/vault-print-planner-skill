# Start-line and print-area checks

In a previous P1S PETG print, springs near Y=2 mm overlapped the front purge line and some first-layer material lifted. Photos showed overlap and deformation, not a definitive cause for every adhesion problem.

That project’s nozzle load line in machine_start_gcode ran X18 to X240 at Y1, rose to Y11 at the right, then returned at X239.5 / Y1.5. This is evidence for one profile, not a universal Bambu path.

Inspect the active project and printer preset:

- Actual extruding start-G-code moves and conditional branches, not just positioning moves.
- Plate coordinate origin and exclusion areas. Multi-plate STL world coordinates may include layout offsets.
- Transformed XY footprint, Z height, supports, brim, skirt, and purge tower.
- Clearance for actual line widths and brim, not merely model bounding boxes.

The bundled planner uses a 230 × 230 mm virtual area translated by +20,+20 mm, with edge=1. Ordinary model boundaries are approximately X/Y=21…249 mm, allowing about 5 mm of brim while clearing the observed front path. This conservative area may reject parts that could fit with careful manual placement. Explain that result, separate plates or save a manual layout, and slice to validate. Never scale models or silently reduce margins. Larger brims and custom start lines require fresh checks.

Keep braces at their original size and verify contact with the shell, interfaces, and removal points. Separate normal parts under one object can prevent automatic layout from separating them, but placement coordinates are model-specific. Never reuse one M5 x5 placement as a universal algorithm.

Inspect the first layer of every changed plate, especially the front edge, right-hand return, and model perimeter. Check for overlaps, unsupported first layers, and out-of-bounds support. Record slicer weight/time estimates and warnings. Unsliced plates have only passed geometric preflight.

Editing a computer project does not update an already sent print. If parts lift or detach, have the user pause or cancel first; never clean around a moving machine. Layout changes cannot guarantee resolution of moisture, dirty plates, or flow problems.
