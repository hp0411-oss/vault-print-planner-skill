# 运行与数据

## 环境

Python 3.11+，依赖 `numpy`, `Pillow`, `pypdf`，本机安装并初始化 Bambu Studio。使用已有兼容 Python 环境，或为本工具建立 venv 后安装仓库根目录 requirements.txt。

`python scripts/launch.py --archive '/path/to/VAULT' --port 8766`

archive 应直接包含 `01. DRAWERS`、`02. SUSTAINERS`、`03. MODIFICATIONS`。网页位于 `http://127.0.0.1:8766/planner.html`，可在 Chrome 或内置浏览器打开。默认绑定本机；服务没有远程用户认证，不部署公网。

随附应用位于 `assets/app/`，运行时会在其中生成 cache、assets/help、print-jobs、print-progress.json、output。它们是本地状态，不能提交。默认离线，不下载设计师渲染图；首次运行会从用户本地 PDF 提取帮助图片。没有公开打包设计师的耗材统计，估算以本地几何和预设为准，最终以切片结果为准。

## 应用模块

- planner.html、planner-preview.js：中文选择器、简化装配与单件 STL 查看。
- accessories.py：配件选项与成套依赖。
- planner.py：P1S 预设、校验、任务保存/恢复/导出。
- overview.py、planner-overview.js：手动完成记录及四列组合规划。
- catalog.py：型号与零件对应；plates.py / mesh.py：几何、排板和 3MF。

## API（使用前读取当前实现，避免误用旧 schema）

GET `/api/planner/jobs`、`/api/planner/deleted`、`/api/planner/overview`。
POST `/api/planner/preview`、`/api/planner/save` 接收 stack、material、nozzle。
POST `/api/planner/accessories`、`/api/planner/visual` 返回配件或预览清单。
POST `/api/planner/export`、`/api/planner/open`、`/api/planner/delete`、`/api/planner/restore` 接收 id。
POST `/api/planner/progress` 的目标/完成/列/顺序字段以 overview.py 为准。

导出是异步任务，查看 jobs 中 status / error。ready 仅代表生成工程。打开 Studio 的接口目前仅支持 macOS；其他系统手动打开导出的 3MF。预设自动发现受本机安装路径影响。

## 限制

这份包从原本地工具整理而来，不包含此前一次性手动调整的 M5 工程。宽度/深度相同不代表所有改装兼容；特殊改装回到用户持有的说明书逐项核对。自动支撑关联、复杂多列组合和材料强度不由简化预览保证。
