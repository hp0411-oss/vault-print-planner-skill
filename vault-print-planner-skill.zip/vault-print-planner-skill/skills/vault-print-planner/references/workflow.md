# Runtime and data

Use Python 3.11+ with numpy, Pillow, and pypdf, and initialize Bambu Studio locally. Reuse a compatible environment or install the repository requirements in a virtual environment.

Run `python scripts/launch.py --archive '/path/to/VAULT' --port 8766` from the skill folder. The archive should directly contain `01. DRAWERS`, `02. SUSTAINERS`, and `03. MODIFICATIONS`. Open `http://127.0.0.1:8766/planner.html` in Chrome or another browser. Select Chinese or English at the top right. The service binds to loopback and has no remote authentication; do not expose it publicly.

The bundled app is in `assets/app/`. Runtime cache, help images, print-jobs, print-progress.json, and output are local data and must not be committed. Offline mode extracts help images from the user’s local manuals instead of downloading designer renders. Designer print statistics are excluded; use slicer results for final estimates.

## Modules

- planner.html / planner-preview.js: Chinese configuration and simplified assembly / STL previews; generated `-en` variants provide English.
- planner-language.js / translations.json: locale persistence and system-response translation; preserve user text and filenames.
- accessories.py: accessory choices and complete-file dependencies.
- planner.py: P1S profiles, validation, saved tasks, recovery, and export.
- overview.py / planner-overview.js: manual completion records and four-column planning.
- catalog.py: model-to-part mapping; plates.py / mesh.py: geometry, arrangement, and 3MF.

## API

Read the implementation before using a schema from memory.

- GET `/api/planner/jobs`, `/api/planner/deleted`, `/api/planner/overview`.
- POST `/api/planner/preview`, `/api/planner/save`: stack, material, nozzle.
- POST `/api/planner/accessories`, `/api/planner/visual`: accessory or preview lists.
- POST `/api/planner/export`, `/api/planner/open`, `/api/planner/delete`, `/api/planner/restore`: id.
- POST `/api/planner/progress`: see overview.py for target, printed, column, order, and note.

Export is asynchronous: inspect task status/error. Ready means exported, not printed. Automatic opening currently supports macOS; elsewhere open exported 3MF files manually. Profile discovery depends on local installation paths.

This package excludes previous manually adjusted print projects. Matching width/depth does not prove compatibility for every modification. Verify special modifications against the user’s manuals. Simplified previews do not guarantee brace placement, complex assemblies, or material strength.
