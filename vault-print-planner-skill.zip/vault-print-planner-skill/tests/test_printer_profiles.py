"""Run with Python + numpy installed: python -m unittest discover -s tests."""
import sys, unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'skills/vault-print-planner/assets/app'))
import printer_profiles as pp
import planner, plates

class GeometryTests(unittest.TestCase):
    def machine(self,w=256,h=256):
        return dict(printable_area=['0x0',f'{w}x0',f'{w}x{h}',f'0x{h}'],printable_height='250',bed_exclude_area=[])
    def test_small_bed_rejects_part_that_fits_large_bed(self):
        g=pp.geometry(self.machine(180,180));large=pp.geometry(self.machine())
        def printer(g):return dict(bed=g['planningBed'],z=250,maxH=250)
        self.assertIsNone(plates.fits([170,170,20],printer(g),1))
        self.assertIsNotNone(plates.fits([170,170,20],printer(large),1))
    def test_exclusion_with_clearance_is_not_in_planning_rectangle(self):
        m=self.machine();m['bed_exclude_area']=['0x0','18x0','18x28','0x28'];g=pp.geometry(m)
        self.assertEqual(g['offset'],[23,20]);self.assertEqual(g['planningBed'],[227,230])
    def test_invalid_and_non_rectangular_beds_fail(self):
        for area in [['0x0','180x0','170x180','0x180'],['0x0','nanx0','nanx180','0x180']]:
            with self.assertRaises(ValueError):pp.geometry({**self.machine(),'printable_area':area})
    def test_dual_nozzle_rejected(self):
        m={**self.machine(),'name':'Bambu Lab Test 0.4 nozzle','printer_model':'Bambu Lab Test','nozzle_diameter':['0.4','0.4']}
        with patch.object(pp.presets,'load_all',return_value={m['name']:m}):
            with self.assertRaisesRegex(ValueError,'Dual-nozzle'):pp.resolve('Bambu Lab Test')
    def test_missing_profile_never_falls_back_to_p1s(self):
        with patch.object(pp.presets,'load_all',return_value={}):
            with self.assertRaisesRegex(ValueError,'Missing'):pp.resolve('Bambu Lab A1 mini')
    def test_incompatible_material_never_falls_back(self):
        with patch.object(pp,'resolve',return_value=('machine',{},{})),patch.object(pp,'compatible_rows',side_effect=[[{'name':'Standard'}],[{'name':'PLA-CF','material':'PLA-CF'}]]):
            with self.assertRaisesRegex(ValueError,'Missing compatible PLA'):planner.settings('PLA')

if __name__=='__main__':unittest.main()
